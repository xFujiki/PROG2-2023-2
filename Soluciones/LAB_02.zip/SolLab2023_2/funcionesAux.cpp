/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   funcionesAux.cpp
 * Author: Adrian Fujiki
 * 
 * Created on 19 de febrero de 2024, 04:32 PM
 */

#include "funcionesAux.h"
#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
#define MAX_LONG 140

using namespace std;
//Elaborado por Adrian Fujiki

//Parte 1
void aperturaParaLeer(ifstream &arch,const char *cad){
    arch.open(cad,ios::in);
    if(!arch){
        cout<<"ERROR: No se ha podido abrir el archivo "<<cad<<endl;
        exit(1);
    }
}

void aperturaParaEscribir(ofstream &arch,const char *cad){
    arch.open(cad,ios::out);
    if(!arch){
        cout<<"ERROR: No se ha podido abrir el archivo "<<cad<<endl;
        exit(1);
    }
}

void lecturaDeProductos(const char*cad,char ***&productos,int *&stock,double *&precios){
    //definiendo los buffers
    char **bf_pro[200]{};
    int bf_stock[200]{};
    double bf_precios[200]{};
    
    int nd=0;
    
    ifstream arch;
    aperturaParaLeer(arch,cad);
    
    char *cod,*desc;
    while(1){
        cod=leerCadena(arch);
        if(cod==nullptr)break;
        desc=leerCadena(arch);
        arch>>bf_precios[nd];
        arch.get();
        arch>>bf_stock[nd];
        arch.get();
        //luego de la lectura
        asignaNombreYDesc(bf_pro[nd],cod,desc);
        nd++;
    }
    
    //inicializar arreglos dinamicos
    productos=new char**[nd+1]{};
    stock=new int[nd+1]{};
    precios=new double[nd+1]{};
    
    //copiando datos
    for(int i=0;i<=nd;i++){ //aqui debe ser menor igual
        productos[i]=bf_pro[i];
        stock[i]=bf_stock[i];
        precios[i]=bf_precios[i];
    }
}

void pruebaDeLecturaDeProductos(const char*cad,char ***productos,int *stock,double *precios){
    ofstream rep;
    aperturaParaEscribir(rep,cad);
    
    rep<<"Codigo"<<setw(30)<<"Nombre"<<setw(48)<<"Stock"<<setw(13)<<"Precio"<<endl;
    for(int i=0;productos[i]!=nullptr;i++){
        imprimeNombreYDesc(rep,productos[i]);
        rep<<setw(10)<<stock[i]<<setprecision(2)<<fixed<<setw(15)<<precios[i]<<endl;
    }
}

void imprimeLinea(ofstream &rep,int cant,char car){
    rep<<endl;
    for(int i=0;i<cant;i++){
        rep<<car;
    }
    rep<<endl;
}

void imprimeNombreYDesc(ofstream &rep,char **pro){
    rep<<pro[0]<<setw(5)<<" "<<left<<setw(60)<<pro[1]<<right;
}

void asignaNombreYDesc(char **&pro,char *cod,char *desc){
    pro=new char*[2]{};
    pro[0]=cod;
    pro[1]=desc;
}

char *leerCadena(ifstream &arch){
    char aux[100]{},*cad;
    arch.getline(aux,100,','); //esto ya descarta la coma
    if(arch.eof())return nullptr;
    cad=new char[strlen(aux)+1]{};
    strcpy(cad,aux);
    return cad;
}

//Parte 2
void lecturaDePedidos(const char *cad,int *&fechaPedidos,char ***&codigoPedidos,
        int ***&dniCantPedidos){
    int bf_fecha[200]{};
    char **bf_pedidos[200]{};
    int **bf_dni[200]{};
    
    ifstream arch;
    aperturaParaLeer(arch,cad);
    
    char *cod,c;
    int dni,cant,fecha,dd,aa,mm,nd=0,pos;
    
    //arreglos auxiliares para controlar segundo nivel
    int cantPed[200]{};
    while(1){
        cod=leerCadena(arch);
        if(cod==nullptr)break;
        arch>>dni;
        arch.get();
        arch>>cant;
        arch.get();
        arch>>dd>>c>>mm>>c>>aa;
        arch.get();
        
        fecha=aa*10000+mm*100+dd;
        
        if(existeFecha(bf_fecha,fecha)==1){ //si existe se busca la pos y se actualiza
            pos=buscarPos(bf_fecha,fecha);
        }else{ //si no existe se agrega al arreglo y se actualiza
            pos=nd;
            bf_fecha[pos]=fecha;
            nd++; //Esto solo aumenta si es que la fecha es nueva
        }
        //actualizando en ambos casos
        actualizarPedidos(bf_pedidos[pos],bf_dni[pos],cantPed[pos],cod,dni,cant);
    }

    //recortando espacios vacios
    for(int i=0;i<nd;i++){ //Solo recortas los validos, el ultimo espacio no es recortable
        recortarPedidos(bf_pedidos[i],bf_dni[i],cantPed[i]);
    }
    
    //generando espacio de memoria
    fechaPedidos=new int[nd+1]{};
    codigoPedidos=new char**[nd+1]{};
    dniCantPedidos=new int**[nd+1]{};
    
    for(int i=0;i<=nd;i++){ //Aca es nd porque el while siempre recorre una vez mas
        fechaPedidos[i]=bf_fecha[i];
        codigoPedidos[i]=bf_pedidos[i];
        dniCantPedidos[i]=bf_dni[i];
    }
}

void pruebaDeLecturaDePedidos(const char*cad,int *fecha,char ***fechaPeds,int***dniCant){
    ofstream rep;
    aperturaParaEscribir(rep,cad);
    for(int i=0;fecha[i]!=0;i++){
        rep<<fecha[i]<<endl;
        rep<<"Pedidos:"<<endl;
        imprimePedidos(rep,fechaPeds[i],dniCant[i]);
    }
}

void imprimePedidos(ofstream &rep,char **peds,int **dniCant){
    for(int i=0;peds[i]!=nullptr;i++){
        rep<<setw(2)<<i+1<<") "<<peds[i];
        imprimeDniCant(rep,dniCant[i]);
    }
}

void imprimeDniCant(ofstream &rep,int *dniCant){
    rep<<setw(15)<<dniCant[0]<<setw(10)<<dniCant[1]<<endl;
}

void recortarPedidos(char **&peds,int **&dniCant,int cantPed){
    char **aux_peds=new char*[cantPed+1]{};
    int **aux_dni=new int*[cantPed+1]{};
    
    //copiando los datos a arreglos auxiliares
    for(int i=0;i<=cantPed;i++){
        aux_peds[i]=peds[i];
        aux_dni[i]=dniCant[i];
    }
    delete peds;
    delete dniCant;
    peds=aux_peds;
    dniCant=aux_dni;
}

void actualizarPedidos(char **&peds,int **&dniCant,int &cantPed,char *cod,int dni,int cant){
    if(cantPed==0){//Si aun no hay pedidos se genera un buffer dinamico
        peds=new char*[50]{};
        dniCant=new int*[50]{};
    }
    peds[cantPed]=cod; //como son dos cadenas dinamicas es valido realizar esto
    dniCant[cantPed]=new int[2];
    asignaDniCant(dniCant[cantPed],dni,cant);
    cantPed++;
}

void asignaDniCant(int *dniCant,int dni,int cant){
    dniCant[0]=dni;
    dniCant[1]=cant;
}

int buscarPos(int *arr_fecha,int fecha){
    for(int i=0;arr_fecha[i]!=0;i++){
        if(arr_fecha[i]==fecha)return i;
    }
}

int existeFecha(int *arr_fecha,int fecha){
    for(int i=0;arr_fecha[i]!=0;i++){
        if(arr_fecha[i]==fecha)return 1;
    }
    return 0;
}

//Parte 3
void reporteDeEnvioDePedidos(const char *cad,char ***productos,int *stock,double *precios,
        int *fechaPedidos,char ***codigoPedidos,int ***dniCantPedidos){
    ofstream rep;
    aperturaParaEscribir(rep,cad);
    
    for(int i=0;fechaPedidos[i]!=0;i++){
        imprimeLinea(rep,'=',MAX_LONG);
        rep<<"FECHA: "<<fechaPedidos[i];
        imprimeLinea(rep,'=',MAX_LONG);
        rep<<"No. "<<setw(5)<<"DNI"<<setw(30)<<"Producto"<<setw(62)<<"Cantidad"<<
                setw(11)<<"Precio"<<setw(25)<<"Total de ingresos";
        imprimeLinea(rep,'-',MAX_LONG);
        
        imprimePedsFinal(rep,codigoPedidos[i],dniCantPedidos[i],productos,stock,precios);
        imprimeLinea(rep,'=',MAX_LONG);
        rep<<endl;
    }
}

void imprimePedsFinal(ofstream &rep,char **peds,int **dniCant,char ***productos,
        int *stock,double *precios){
    int *aux;
    double totalIng=0,totalPer=0;
    for(int i=0;peds[i]!=nullptr;i++){
        aux=dniCant[i]; //otra forma de modular
        rep<<setw(2)<<i+1<<") "<<aux[0]<<setw(5)<<" "<<left<<setw(15)<<peds[i];
        imprimePro(rep,peds[i],aux[1],productos,stock,precios,totalIng,totalPer);
    }
    imprimeLinea(rep,'-',MAX_LONG);
    rep<<"Total ingresado: "<<setw(114)<<setprecision(2)<<fixed<<totalIng<<endl<<
            "Total perdido por falta de stock: "<<setw(97)<<totalPer;
}

void imprimePro(ofstream &rep,char *cod,int cant,char ***pro,int *stock,double *precios,
        double &totalIng,double &totalPer){
    char **aux;
    for(int i=0;pro[i]!=nullptr;i++){
        aux=pro[i];
        if(strcmp(aux[0],cod)==0){
            rep<<setw(60)<<aux[1]<<right<<setw(5)<<cant
                <<setprecision(2)<<fixed<<setw(15)<<precios[i];
            if(stock[i]<cant){
                rep<<setw(20)<<"SIN STOCK"<<endl;
                totalPer+=precios[i]*cant;
            }else{
                rep<<setw(19)<<precios[i]*cant<<endl;
                //descontando el stock
                stock[i]-=cant;
                totalIng+=precios[i]*cant;
            }
        }
    }
}

void imprimeLinea(ofstream &rep,char car,int cant){
    rep<<endl;
    for(int i=0;i<cant;i++){
        rep<<car;
    }
    rep<<endl;
}