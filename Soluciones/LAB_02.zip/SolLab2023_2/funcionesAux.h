/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   funcionesAux.h
 * Author: Adrian Fujiki
 *
 * Created on 19 de febrero de 2024, 04:32 PM
 */

#ifndef FUNCIONESAUX_H
#define FUNCIONESAUX_H
#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>

using namespace std;
//Elaborado por Adrian Fujiki

//Parte 1
void aperturaParaLeer(ifstream &arch,const char *cad);
void aperturaParaEscribir(ofstream &arch,const char *cad);
void lecturaDeProductos(const char*cad,char ***&productos,int *&stock,double *&precios);
void asignaNombreYDesc(char **&pro,char *cod,char *desc);
char *leerCadena(ifstream &arch);
void pruebaDeLecturaDeProductos(const char*cad,char ***productos,int *stock,double *precios);
void imprimeNombreYDesc(ofstream &rep,char **pro);
//Parte 2
void lecturaDePedidos(const char *cad,int *&fechaPedidos,char ***&codigoPedidos,
        int ***&dniCantPedidos);
void actualizarPedidos(char **&peds,int **&dniCant,int &cantPed,char *cod,int dni,int cant);
void asignaDniCant(int *dniCant,int dni,int cant);
int buscarPos(int *arr_fecha,int fecha);
int existeFecha(int *arr_fecha,int fecha);
void recortarPedidos(char **&peds,int **&dniCant,int cantPed);
void pruebaDeLecturaDePedidos(const char*cad,int *fecha,char ***fechaPeds,int***dniCant);
void imprimePedidos(ofstream &rep,char **peds,int **dniCant);
void imprimeDniCant(ofstream &rep,int *dniCant);
//Parte 3
void reporteDeEnvioDePedidos(const char *cad,char ***productos,int *stock,double *precios,
        int *fechaPedidos,char ***codigoPedidos,int ***dniCantPedidos);
void imprimePedsFinal(ofstream &rep,char **peds,int **dniCant,char ***productos,
        int *stock,double *precios);
void imprimePro(ofstream &rep,char *cod,int cant,char ***pro,int *stock,double *precios,
        double &totalIng,double &totalPer);
void imprimeLinea(ofstream &rep,char car,int cant);
#endif /* FUNCIONESAUX_H */
