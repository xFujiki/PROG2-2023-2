/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Flota.cpp
 * Author: alulab14
 * 
 * Created on 10 de noviembre de 2023, 08:11 AM
 */

#include "Flota.h"
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <cstring>
#include <iomanip>
#include "LVehiculos.h"
using namespace std;
Flota::Flota() {
}

Flota::Flota(const Flota& orig) {
}

Flota::~Flota() {
}

void Flota::cargaflota(){
    ifstream arch;
    arch.open("Vehiculos.csv",ios::in);
    if(!arch){
        cout<<"ERROR: No se ha podido abrir el archivo de vehiculos"<<endl;
        exit(1);
    }
    lista.leeVehiculos(arch);
}

void Flota::muestracarga(){
    ofstream rep;
    rep.open("ReporteDeFlota.txt",ios::out);
    if(!rep){
        cout<<"ERROR: No se ha podido abrir el archivo de reporte de vehiculos"<<endl;
        exit(1);
    }
    rep<<"REPORTE DE FLOTA"<<endl;
    for(int i=0;i<50;i++){
        rep<<'=';
    }
    rep<<endl;
    lista.imprimeVehiculos(rep);
}

void Flota::cargapedidos(){
    ifstream arch;
    arch.open("Pedidos3.csv",ios::in);
    if(!arch){
        cout<<"ERROR: No se ha podido abrir el archivo de pedidos"<<endl;
        exit(1);
    }
    lista.leePedidos(arch);
} 