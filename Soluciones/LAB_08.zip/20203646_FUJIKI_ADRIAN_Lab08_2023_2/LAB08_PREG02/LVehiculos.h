/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   LVehiculos.h
 * Author: alulab14
 *
 * Created on 10 de noviembre de 2023, 08:10 AM
 */

#ifndef LVEHICULOS_H
#define LVEHICULOS_H
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <cstring>
#include <iomanip>
#include "NodoLista.h"
#include "Vehiculo.h"
using namespace std;
class LVehiculos {
public:
    LVehiculos();
    LVehiculos(const LVehiculos& orig);
    virtual ~LVehiculos();
    void leeVehiculos(ifstream &);
    void insertarVehiculo(Vehiculo *);
    void imprimeVehiculos(ofstream &);
    void leePedidos(ifstream &);
    void insertaPedido(int dni,int cantidad,double peso,char *cod);
private:
    class NodoLista *lini;
    class NodoLista *lfin;
};

#endif /* LVEHICULOS_H */

