/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   NPedido.h
 * Author: alulab14
 *
 * Created on 10 de noviembre de 2023, 08:00 AM
 */

#ifndef NPEDIDO_H
#define NPEDIDO_H
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <cstring>
#include <iomanip>
#include "Vehiculo.h"
using namespace std;
class NPedido {
public:
    NPedido();
    NPedido(const NPedido& orig);
    friend class Vehiculo;
    virtual ~NPedido();
    void SetPeso(double peso);
    double GetPeso() const;
    void SetCantidad(int cantidad);
    int GetCantidad() const;
    void SetCodigo(const char* codigo);
    void GetCodigo(char *) const;
    void impimePed(ofstream &);
    void leePedido(char *,int ,double);
private:
    char *codigo;
    int cantidad;
    double peso;
    NPedido *sig;
};

#endif /* NPEDIDO_H */

