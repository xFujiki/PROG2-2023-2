/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Flota.h
 * Author: alulab14
 *
 * Created on 10 de noviembre de 2023, 08:11 AM
 */

#ifndef FLOTA_H
#define FLOTA_H
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <cstring>
#include <iomanip>
#include "LVehiculos.h"
using namespace std;
class Flota {
public:
    Flota();
    Flota(const Flota& orig);
    virtual ~Flota();
    void cargaflota();
    void muestracarga();
    void cargapedidos();
private:
    LVehiculos lista; //cada cliente tiene un vehiculo
};

#endif /* FLOTA_H */

