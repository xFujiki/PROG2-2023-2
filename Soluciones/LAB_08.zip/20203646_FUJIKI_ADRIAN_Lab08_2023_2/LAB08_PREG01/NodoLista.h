/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   NodoLista.h
 * Author: alulab14
 *
 * Created on 10 de noviembre de 2023, 08:09 AM
 */

#ifndef NODOLISTA_H
#define NODOLISTA_H
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <cstring>
#include <iomanip>
#include "Vehiculo.h"
#include "LVehiculos.h"
using namespace std;
class NodoLista {
public:
    NodoLista();
    NodoLista(const NodoLista& orig);
    virtual ~NodoLista();
    friend class LVehiculos;
private:
    Vehiculo *unidad;
    NodoLista *sig;
};

#endif /* NODOLISTA_H */

