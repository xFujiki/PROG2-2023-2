/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   LVehiculos.cpp
 * Author: alulab14
 * 
 * Created on 10 de noviembre de 2023, 08:10 AM
 */

#include "LVehiculos.h"
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <cstring>
#include <iomanip>
#include "Vehiculo.h"
#include "Camion.h"
#include "Furgon.h"
using namespace std;
LVehiculos::LVehiculos() {
    lfin=nullptr;
    lini=nullptr;
}

LVehiculos::LVehiculos(const LVehiculos& orig) {
}

LVehiculos::~LVehiculos() {
    if(lini!=nullptr){
        delete lfin;
    }
    if(lfin!=nullptr){
        delete lfin;
    }
}

void LVehiculos::leeVehiculos(ifstream& arch){
    char tipo;
    //creando objeto auxiliar
    Vehiculo *veh;
    while(1){
        arch>>tipo;
        if(arch.eof())break;
        //generando segun tipo
        if(tipo=='C'){
            veh=new Camion;
        }
        if(tipo=='F'){
            veh=new Furgon;
        }
        arch.get(); //descartando coma
        veh->lee(arch); //armando objeto
        insertarVehiculo(veh); //insertando objeto en la lista
    }
}

void LVehiculos::insertarVehiculo(Vehiculo* veh){
    NodoLista *nuevo=new NodoLista;
    nuevo->unidad=veh;
    if(!lini){
        lini=nuevo;
    }else{
        NodoLista *actual=lini;
        while(actual->sig){
            actual=actual->sig;
        }
        actual->sig=nuevo;
    }
}

void LVehiculos::imprimeVehiculos(ofstream& rep){
    NodoLista *aux;
    NodoLista *auxLista=lini;
    
    while(auxLista){
        aux=auxLista;
        aux->unidad->imprime(rep);
        rep<<endl;
        auxLista=auxLista->sig;
    }
}