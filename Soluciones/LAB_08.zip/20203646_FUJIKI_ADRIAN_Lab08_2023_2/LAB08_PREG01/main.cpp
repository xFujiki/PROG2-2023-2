/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: alulab14
 *
 * Created on 10 de noviembre de 2023, 07:59 AM
 */

#include <cstdlib>
#include <fstream>
#include <iostream>
#include <cstring>
#include <iomanip>
#include "Flota.h"
using namespace std;

//Elaborado por Adrian Masashiri Fujiki Escobar 202023646
int main(int argc, char** argv) {
    Flota transporte;
    
    transporte.cargaflota();
    transporte.muestracarga();
    return 0;
}

