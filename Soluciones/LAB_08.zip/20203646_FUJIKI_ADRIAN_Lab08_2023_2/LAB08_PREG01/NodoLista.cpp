/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   NodoLista.cpp
 * Author: alulab14
 * 
 * Created on 10 de noviembre de 2023, 08:09 AM
 */

#include "NodoLista.h"
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <cstring>
#include <iomanip>
using namespace std;
NodoLista::NodoLista() {
    sig=nullptr;
    unidad=nullptr;
}

NodoLista::NodoLista(const NodoLista& orig) {
}

NodoLista::~NodoLista() {
    if(unidad!=nullptr)delete unidad;
    if(sig!=nullptr)delete sig;
}

