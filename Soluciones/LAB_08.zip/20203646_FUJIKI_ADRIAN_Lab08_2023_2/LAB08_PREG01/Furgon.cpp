/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Furgon.cpp
 * Author: alulab14
 * 
 * Created on 10 de noviembre de 2023, 08:07 AM
 */

#include "Furgon.h"
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <cstring>
#include <iomanip>
using namespace std;
Furgon::Furgon() {
    filas=0;
    puertas=0;
}

Furgon::Furgon(const Furgon& orig) {
}

Furgon::~Furgon() {
}

void Furgon::SetPuertas(int puertas) {
    this->puertas = puertas;
}

int Furgon::GetPuertas() const {
    return puertas;
}

void Furgon::SetFilas(int filas) {
    this->filas = filas;
}

int Furgon::GetFilas() const {
    return filas;
}

void Furgon::lee(ifstream& arch) {
    Vehiculo::lee(arch);
    char c;
    arch>>filas>>c>>puertas>>ws;
}

void Furgon::imprime(ofstream& rep) {
    Vehiculo::imprime(rep);
    rep<<"#Filas: "<<setw(22)<<filas<<endl<<"#Puertas: "<<setw(20)<<puertas<<endl;
}
