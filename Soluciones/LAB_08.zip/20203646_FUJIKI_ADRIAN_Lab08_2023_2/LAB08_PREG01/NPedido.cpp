/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   NPedido.cpp
 * Author: alulab14
 * 
 * Created on 10 de noviembre de 2023, 08:00 AM
 */

#include "NPedido.h"
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <cstring>
#include <iomanip>
using namespace std;
NPedido::NPedido() {
    cantidad=0;
    codigo=nullptr;
    peso=0;
    sig=nullptr;
}

NPedido::NPedido(const NPedido& orig) {
}

NPedido::~NPedido() {
    if(codigo!=nullptr)delete codigo;
    if(sig!=nullptr)delete sig;
}

void NPedido::SetPeso(double peso) {
    this->peso = peso;
}

double NPedido::GetPeso() const {
    return peso;
}

void NPedido::SetCantidad(int cantidad) {
    this->cantidad = cantidad;
}

int NPedido::GetCantidad() const {
    return cantidad;
}

void NPedido::SetCodigo(const char* cad) {
    if(codigo!=nullptr)delete codigo;
    codigo=new char[strlen(cad)+1];
    strcpy(codigo,cad);
}

void NPedido::GetCodigo(char *cad) const {
    strcpy(cad,codigo);
}

