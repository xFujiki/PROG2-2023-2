/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Vehiculo.cpp
 * Author: alulab14
 * 
 * Created on 10 de noviembre de 2023, 08:02 AM
 */

#include "Vehiculo.h"
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <cstring>
#include <iomanip>
using namespace std;
Vehiculo::Vehiculo() {
    actcarga=0;
    cliente=0;
    maxcarga=0;
    ped=nullptr;
    placa=nullptr;
}

Vehiculo::Vehiculo(const Vehiculo& orig) {
}

Vehiculo::~Vehiculo() {
    if(ped!=nullptr)delete ped;
    if(placa!=nullptr)delete placa;
}

void Vehiculo::SetActcarga(double actcarga) {
    this->actcarga = actcarga;
}

double Vehiculo::GetActcarga() const {
    return actcarga;
}

void Vehiculo::SetMaxcarga(double maxcarga) {
    this->maxcarga = maxcarga;
}

double Vehiculo::GetMaxcarga() const {
    return maxcarga;
}

void Vehiculo::SetPlaca(const char* cad) {
    if(placa!=nullptr)delete placa;
    placa=new char[strlen(cad)+1];
    strcpy(placa,cad);
}

void Vehiculo::GetPlaca(char *cad) const {
    strcpy(placa,cad);
}

void Vehiculo::SetCliente(int cliente) {
    this->cliente = cliente;
}

int Vehiculo::GetCliente() const {
    return cliente;
}

void Vehiculo::lee(ifstream& arch){
    char c,aux[100];
    arch>>cliente>>c;
    arch.getline(aux,100,',');
    SetPlaca(aux);//se leyo hasta la coma
    arch>>maxcarga>>c;
}

void Vehiculo::imprime(ofstream& rep){
    rep<<"Codigo Cliente: " <<setw(14)<<cliente<<endl<<"Placa: "<<setw(23)<<placa<<endl<<
            "Carga Maxima: "<<fixed<<setprecision(2)<<setw(16)<<maxcarga<<endl<<
            "Carga Actual: "<<setw(16)<<actcarga<<endl;
}