/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Camion.h
 * Author: alulab14
 *
 * Created on 10 de noviembre de 2023, 08:05 AM
 */

#ifndef CAMION_H
#define CAMION_H
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <cstring>
#include <iomanip>
#include "Vehiculo.h"
using namespace std;
class Camion :public Vehiculo{
public:
    Camion();
    Camion(const Camion& orig);
    virtual ~Camion();
    void lee(ifstream& arch);
    void imprime(ofstream &rep);
private:
    int ejes;
    int llantas;
};

#endif /* CAMION_H */

