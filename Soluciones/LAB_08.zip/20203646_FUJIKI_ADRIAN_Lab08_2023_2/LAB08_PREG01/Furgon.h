/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Furgon.h
 * Author: alulab14
 *
 * Created on 10 de noviembre de 2023, 08:07 AM
 */

#ifndef FURGON_H
#define FURGON_H
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <cstring>
#include <iomanip>
#include "Vehiculo.h"
using namespace std;
class Furgon :public Vehiculo{
public:
    Furgon();
    Furgon(const Furgon& orig);
    virtual ~Furgon();
    void SetPuertas(int puertas);
    int GetPuertas() const;
    void SetFilas(int filas);
    int GetFilas() const;
    void lee(ifstream& arch);
    void imprime(ofstream &rep);
private:
    int filas;
    int puertas;
};

#endif /* FURGON_H */

