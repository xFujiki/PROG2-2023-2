/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   PilaConEnteros.cpp
 * Author: alulab14
 * 
 * Created on 29 de septiembre de 2023, 08:44 AM
 */

#include "PilaConEnteros.h"
#include <iomanip>
#include <iostream>
#include <fstream>

//Adrian Fujiki Escobar 20203646
using namespace std;

void *leenumero(ifstream &arch){
    double *num=new double;
    arch>>*num;
    if(arch.eof())return nullptr;
    
    return num;
}

double calculanumero(void *dato){
    return *(double *)dato;
}

void imprimenumero(ofstream &rep,void *dato){
    rep<<setprecision(2)<<fixed<<*(double *)dato<<endl;
}

int cmpnumero(const void *a,const void*b){
    void **regA=(void **)a;
    void **regB=(void **)b;
    
    void **detA=(void **)*regA;
    void **detB=(void **)*regB;
    
    return *(double *)detB[1]-*(double *)detA[1];
}