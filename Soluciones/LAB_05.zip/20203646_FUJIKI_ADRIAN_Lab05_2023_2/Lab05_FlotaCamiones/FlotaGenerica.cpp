/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   FlotaGenerica.cpp
 * Author: alulab14
 * 
 * Created on 29 de septiembre de 2023, 08:09 AM
 */
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include "FlotaGenerica.h"

//Adrian Fujiki Escobar 20203646
using namespace std;
void AperturaParaLeer(ifstream &arch,const char*cad){
    arch.open(cad,ios::in);
    if(!arch){
        cout<<"ERROR: No se ha podido abrir: "<<cad<<endl;
        exit(1);
    }
}
void AperturaParaEscribir(ofstream &arch,const char*cad){
    arch.open(cad,ios::out);
    if(!arch){
        cout<<"ERROR: No se ha podido abrir: "<<cad<<endl;
        exit(1);
    }
}

void cargacamiones(void *&flota,int numcamiones,int pesomaximo,
        void *(*lee)(ifstream &),double(*calcula)(void *),
            const char*nombArch){
    
    ifstream arch;
    AperturaParaLeer(arch,nombArch);
    void **buff=new void*[numcamiones+1]{};//arreglo de pilas
    
    void *dato,*pila;//voy a ver que sucede con esta pila ya que cambia
    double peso_dato,peso_pila;
    
    int salir_for=0;
    
    for(int i=0;i<numcamiones;i++){//solo llena los camiones permitidos
        //if(i==numcamiones)break; //god?
        if(buff[i]==nullptr)generapila(pila);
        buff[i]=pila; 
        if(i>0){
            peso_pila=obtenerPesoPila(pila);
            if(peso_pila+peso_dato<=pesomaximo){
                    push(pila,dato,peso_dato);
            }
        }
        while(1){//va llenando hasta que excede
            dato=lee(arch);
            if(dato==nullptr){
                salir_for=1;
                break;
            }
            peso_dato=calcula(dato);//halla el peso del dato
            peso_pila=obtenerPesoPila(pila);//halla el peso actual pila
            if(peso_pila+peso_dato<=pesomaximo){
                push(pila,dato,peso_dato);
            }else{//si excede cambio de pila
                break;
            }   
        } 
        //if(salir_for==1)break;
    }
    flota=buff;
}

double obtenerPesoPila(void *&pila){
    void **reg=(void **)pila;
    return *(double*)reg[1];
}

void muestracamiones(void *flota,int numcamiones,void (*imprime)(ofstream&,void *),
        const char*nombArch){//imprime pila
    ofstream rep;
    AperturaParaEscribir(rep,nombArch);
    
    void **camiones=(void **)flota;
    void **peso;
    for(int i=0;i<numcamiones;i++){
        void **dupla=(void **)camiones[i];
        void **aux=(void **)dupla[0];
        rep<<"Camion:   "<<i+1<<":Peso:"<<setprecision(2)<<fixed<<*(double*)dupla[1]<<endl;
        while(aux!=nullptr){
            imprime(rep,aux[1]);
            aux=(void **)aux[0];
        }
    }
}

void push(void *&pila,void *dato,double peso){
    void **aux=(void **)pila;
    void **nuevo;
    double *cont; //peso
    
    nuevo=new void*[2];
    nuevo[1]=dato;
    nuevo[0]=nullptr;
    if(pilavacia(pila)){
        aux[0]=nuevo;
    }else{
        nuevo[0]=aux[0];
        aux[0]=nuevo;
    }
    *(double *)aux[1]+=peso;
}

int pilavacia(void *pila){
    void **dupla=(void **)pila;
    if(dupla[0]==nullptr)return 1;
    return 0;
}

void generapila(void *&pila){
    void **aux=new void*[2];
    aux[0]=nullptr;
    double*cant=new double;
    *cant=0;//peso 0 inicial
    aux[1]=cant;
    pila=aux;
}