/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   PilaConRegistros.h
 * Author: alulab14
 *
 * Created on 29 de septiembre de 2023, 08:47 AM
 */

#ifndef PILACONREGISTROS_H
#define PILACONREGISTROS_H
#include <fstream>

using namespace std;
#endif /* PILACONREGISTROS_H */
