/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   FlotaGenerica.h
 * Author: alulab14
 *
 * Created on 29 de septiembre de 2023, 08:09 AM
 */

#ifndef FLOTAGENERICA_H
#define FLOTAGENERICA_H
#include <fstream>

using namespace std;
void AperturaParaLeer(ifstream &arch,const char*cad);
void AperturaParaEscribir(ofstream &arch,const char*cad);
void cargacamiones(void *&flota,int numcamiones,int pesomaximo,
        void *(*lee)(ifstream &),double(*calcula)(void *),
            const char*nombArch);
double obtenerPesoPila(void *&pila);
void push(void *&pila,void *dato,double peso);
void muestracamiones(void *flota,int numcamiones,void (*imprime)(ofstream&,void *),
        const char*nombArch);
int pilavacia(void *pila);
void generapila(void *&pila);
#endif /* FLOTAGENERICA_H */
