/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   PilaConEnteros.h
 * Author: alulab14
 *
 * Created on 29 de septiembre de 2023, 08:44 AM
 */

#ifndef PILACONENTEROS_H
#define PILACONENTEROS_H
#include <fstream>

using namespace std;
void *leenumero(ifstream &arch);
double calculanumero(void *dato);
int cmpnumero(const void *a,const void*b);
void imprimenumero(ofstream &rep,void *dato);
#endif /* PILACONENTEROS_H */
