/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Almacen.cpp
 * Author: alulab14
 * 
 * Created on 27 de octubre de 2023, 08:16 AM
 */

#include "Almacen.h"
#include <cstring>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstdlib>
using namespace std;
Almacen::Almacen() {
    cantidad_clientes=0;
    cantidad_productos=0;
}

Almacen::Almacen(const Almacen& orig) {
}

Almacen::~Almacen() {
}

void Almacen::SetCantidad_productos(int cantidad_productos) {
    this->cantidad_productos = cantidad_productos;
}

int Almacen::GetCantidad_productos() const {
    return cantidad_productos;
}

void Almacen::SetCantidad_clientes(int cantidad_clientes) {
    this->cantidad_clientes = cantidad_clientes;
}

int Almacen::GetCantidad_clientes() const {
    return cantidad_clientes;
}

