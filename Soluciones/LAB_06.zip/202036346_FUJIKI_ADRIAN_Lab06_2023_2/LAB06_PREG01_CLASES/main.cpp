/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: alulab14
 *
 * Created on 27 de octubre de 2023, 08:00 AM
 */

#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iostream>
#include <iomanip>
#include "Cliente.h"
#include "Pedido.h"
#include "Producto.h"

using namespace std;
//Elaborado por Adrian Masashiri Fujiki Escobar 20203646
int main(int argc, char** argv) {
    ifstream archCli,archPro,archPed;
    archCli.open("Clientes.csv",ios::in);
    archPro.open("Productos.csv",ios::in);
    archPed.open("Pedidos.csv",ios::in);
    if(!archCli){
        cout<<"ERROR:Clientes"<<endl;
        exit(1);
    }
    if(!archPro){
        cout<<"ERROR:Productos"<<endl;
        exit(1);
    }
    if(!archPed){
        cout<<"ERROR:Pedidos"<<endl;
        exit(1);
    }
    
    ofstream rep;
    rep.open("ReporteDePrueba.txt",ios::out);
    
    //Primera impresion
    Cliente cli;
    archCli>>cli;
    
    Producto pro;
    archPro>>pro;
    
    Pedido ped;
    archPed>>ped;
    
    rep<<cli;
    rep<<pro;
    
    rep<<endl;
    
    //Segunda Impresion
    //Harcodeando los datos para ver si las agregaciones funcionan
    pro.SetCodigo("JXD-139");
    cli.SetDni(50375303);
    pro+=ped;
    cli+=ped;
    rep<<cli;
    rep<<pro;
    
    //Tercera impresion 
    //Imprimiendo mas elementos
    rep<<endl;
    archPro>>pro;
    rep<<pro;
    
    archCli>>cli;
    rep<<endl;
    rep<<cli;
    
    //Los datos de las agregaciones quedan asi debido a que han sido hardcodeados
    //Pero los datos iniciales de lectura si son cambiados
    return 0;
}

