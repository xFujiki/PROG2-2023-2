/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Producto.h
 * Author: alulab14
 *
 * Created on 27 de octubre de 2023, 08:07 AM
 */

#ifndef PRODUCTO_H
#define PRODUCTO_H
#include <cstring>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstdlib>
#include "Pedido.h"
using namespace std;
class Producto {
public:
    Producto();
    Producto(const Producto& orig);
    virtual ~Producto();
    void SetCantidad_clientes_no_servidos(int cantidad_clientes_no_servidos);
    int GetCantidad_clientes_no_servidos() const;
    void SetCantidad_clientes_servidos(int cantidad_clientes_servidos);
    int GetCantidad_clientes_servidos() const;
    void SetStock(int stock);
    int GetStock() const;
    void SetPrecio(double precio);
    double GetPrecio() const;
    void SetDescripcion(const char* descripcion);
    void GetDescripcion(char *) const;
    void SetCodigo(const char* codigo);
    void GetCodigo(char *) const;
    bool operator+=(Pedido &ped);
    void imprimeServ(ofstream &rep);
    void imprimeNoServ(ofstream &rep);
private:
    char *codigo;
    char* descripcion;
    double precio;
    int stock;
    int clientes_servidos[20];
    int clientes_no_servidos[20];
    int cantidad_clientes_servidos;
    int cantidad_clientes_no_servidos;
};

bool operator>>(ifstream &arch,Producto &pro);
ofstream &operator<<(ofstream &rep,Producto &pro);
#endif /* PRODUCTO_H */

