/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Almacen.h
 * Author: alulab14
 *
 * Created on 27 de octubre de 2023, 08:16 AM
 */

#ifndef ALMACEN_H
#define ALMACEN_H
#include <cstring>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstdlib>
#include "Cliente.h"
#include "Producto.h"
using namespace std;
class Almacen {
public:
    Almacen();
    Almacen(const Almacen& orig);
    virtual ~Almacen();
    void SetCantidad_productos(int cantidad_productos);
    int GetCantidad_productos() const;
    void SetCantidad_clientes(int cantidad_clientes);
    int GetCantidad_clientes() const;
private:
    Cliente arreglo_clientes[300];//Revisar
    int cantidad_clientes;
    Producto arreglo_productos[300];
    int cantidad_productos;
};

#endif /* ALMACEN_H */

