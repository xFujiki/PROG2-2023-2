/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Pedido.h
 * Author: alulab14
 *
 * Created on 27 de octubre de 2023, 08:14 AM
 */

#ifndef PEDIDO_H
#define PEDIDO_H
#include <cstring>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstdlib>
using namespace std;
class Pedido {
public:
    Pedido();
    Pedido(const Pedido& orig);
    virtual ~Pedido();
    void SetPrecio_producto(double precio_producto);
    double GetPrecio_producto() const;
    void SetDni_cliente(int dni_cliente);
    int GetDni_cliente() const;
    void SetCodigo(const char* codigo);
    void GetCodigo(char *cad) const;
private:
    char *codigo;
    int dni_cliente;
    double precio_producto;
};

bool operator>>(ifstream &arch,Pedido &ped);
#endif /* PEDIDO_H */

