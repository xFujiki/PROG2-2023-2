/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Producto.cpp
 * Author: alulab14
 * 
 * Created on 27 de octubre de 2023, 08:07 AM
 */

#include "Producto.h"
#include "Pedido.h"
#include <cstring>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstdlib>
using namespace std;
Producto::Producto() {
    cantidad_clientes_no_servidos=0;
    cantidad_clientes_servidos=0;
    codigo=nullptr;
    descripcion=nullptr;
    precio=0;
    stock=0;
}

Producto::Producto(const Producto& orig) {
}

Producto::~Producto() {
    delete codigo;
    delete descripcion;
}

void Producto::SetCantidad_clientes_no_servidos(int cantidad_clientes_no_servidos) {
    this->cantidad_clientes_no_servidos = cantidad_clientes_no_servidos;
}

int Producto::GetCantidad_clientes_no_servidos() const {
    return cantidad_clientes_no_servidos;
}

void Producto::SetCantidad_clientes_servidos(int cantidad_clientes_servidos) {
    this->cantidad_clientes_servidos = cantidad_clientes_servidos;
}

int Producto::GetCantidad_clientes_servidos() const {
    return cantidad_clientes_servidos;
}

void Producto::SetStock(int stock) {
    this->stock = stock;
}

int Producto::GetStock() const {
    return stock;
}

void Producto::SetPrecio(double precio) {
    this->precio = precio;
}

double Producto::GetPrecio() const {
    return precio;
}

void Producto::SetDescripcion(const char* cad) {
    if(descripcion!=nullptr)delete descripcion;
    descripcion=new char[strlen(cad)+1];
    strcpy(descripcion,cad);
}

void Producto::GetDescripcion(char *cad) const {
    strcpy(cad,descripcion);
}

void Producto::SetCodigo(const char* cad) {
    if(codigo!=nullptr)delete codigo;
    codigo=new char[strlen(cad)+1];
    strcpy(codigo,cad);
}

void Producto::GetCodigo(char *cad) const {
    strcpy(cad,codigo);
}

bool operator>>(ifstream &arch,Producto &pro){
    char aux[100],c;
    double precio;
    int stock;
    arch.getline(aux,100,',');
    if(arch.eof())return false;
    pro.SetCodigo(aux);
    arch.getline(aux,100,',');
    pro.SetDescripcion(aux);
    arch>>precio>>c>>stock>>ws;
    
    pro.SetPrecio(precio);
    pro.SetStock(stock);
    return true;
}

bool Producto::operator+=(Pedido &ped){
    ped.SetPrecio_producto(precio);
    if(stock>0){//Si cuenta con stock
        clientes_servidos[cantidad_clientes_servidos]=ped.GetDni_cliente();
        cantidad_clientes_servidos++;
        stock--;
        return true;
    }else{
        clientes_no_servidos[cantidad_clientes_no_servidos]=ped.GetDni_cliente();
        cantidad_clientes_no_servidos++;
        return false;
    }
}

void Producto::imprimeServ(ofstream &rep){
    for(int i=0;i<cantidad_clientes_servidos;i++){
        rep<<setw(10)<<clientes_servidos[i];
    }
    rep<<endl;
}

void Producto::imprimeNoServ(ofstream &rep){
    for(int i=0;i<cantidad_clientes_no_servidos;i++){
        rep<<setw(10)<<clientes_no_servidos[i];
    }
    rep<<endl;
}

ofstream &operator<<(ofstream &rep,Producto &pro){
    char aux[100],desc[100];
    pro.GetCodigo(aux);
    pro.GetDescripcion(desc);
    rep<<aux<<setw(5)<<" "<<left<<setw(60)<<desc<<right<<setprecision(2)<<fixed<<
            setw(15)<<pro.GetPrecio()<<setw(10)<<pro.GetStock()<<endl;
    rep<<"Clientes atendidos:    ";
    if(pro.GetCantidad_clientes_servidos()>0){
        pro.imprimeServ(rep);
    }else{
        rep<<"NO SE ATENDIERON PEDIDOS"<<endl;
    }
    
    rep<<"Clientes no atendidos: ";
    if(pro.GetCantidad_clientes_no_servidos()>0){
        pro.imprimeNoServ(rep);
    }else{
        rep<<"NO HAY CLIENTES SIN ATENDER"<<endl;
    }
}