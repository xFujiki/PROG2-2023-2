/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   ProductoEntregado.cpp
 * Author: alulab14
 * 
 * Created on 27 de octubre de 2023, 08:01 AM
 */

#include "ProductoEntregado.h"
#include <cstring>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstdlib>
using namespace std;
ProductoEntregado::ProductoEntregado() {
    codigo=nullptr;
    precio=0;
}

ProductoEntregado::ProductoEntregado(const ProductoEntregado& orig) {
}

ProductoEntregado::~ProductoEntregado() {
    delete codigo;
}

void ProductoEntregado::SetPrecio(double precio) {
    this->precio = precio;
}

double ProductoEntregado::GetPrecio() const {
    return precio;
}

void ProductoEntregado::SetCodigo(const char* cad) {
    if(codigo!=nullptr)delete codigo;
    codigo=new char[strlen(cad)+1];
    strcpy(codigo,cad);
}

void ProductoEntregado::GetCodigo(char *cad) const {
    strcpy(cad,codigo);
}

