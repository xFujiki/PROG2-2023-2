/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Pedido.cpp
 * Author: alulab14
 * 
 * Created on 27 de octubre de 2023, 08:14 AM
 */

#include "Pedido.h"
#include <cstring>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstdlib>
using namespace std;
Pedido::Pedido() {
    codigo=nullptr;
    dni_cliente=0;
    precio_producto=0;
}

Pedido::Pedido(const Pedido& orig) {
}

Pedido::~Pedido() {
    delete codigo;
}

void Pedido::SetPrecio_producto(double precio_producto) {
    this->precio_producto = precio_producto;
}

double Pedido::GetPrecio_producto() const {
    return precio_producto;
}

void Pedido::SetDni_cliente(int dni_cliente) {
    this->dni_cliente = dni_cliente;
}

int Pedido::GetDni_cliente() const {
    return dni_cliente;
}

void Pedido::SetCodigo(const char* cad) {
    if(codigo!=nullptr)delete codigo;
    codigo=new char[strlen(cad)+1];
    strcpy(codigo,cad);
}

void Pedido::GetCodigo(char *cad) const {
    strcpy(cad,codigo);
}

bool operator>>(ifstream &arch,Pedido &ped){
    char aux[100];
    int dni;
    arch.getline(aux,100,',');
    if(arch.eof())return false;
    arch>>dni>>ws;
    
    ped.SetCodigo(aux);
    ped.SetDni_cliente(dni);
    return true;
}