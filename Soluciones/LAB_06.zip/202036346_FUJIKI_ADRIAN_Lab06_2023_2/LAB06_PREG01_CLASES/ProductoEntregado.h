/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   ProductoEntregado.h
 * Author: alulab14
 *
 * Created on 27 de octubre de 2023, 08:01 AM
 */

#ifndef PRODUCTOENTREGADO_H
#define PRODUCTOENTREGADO_H
#include <cstring>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstdlib>
using namespace std;
class ProductoEntregado {
public:
    ProductoEntregado();
    ProductoEntregado(const ProductoEntregado& orig);
    virtual ~ProductoEntregado();
    void SetPrecio(double precio);
    double GetPrecio() const;
    void SetCodigo(const char* codigo);
    void GetCodigo(char *cad) const;
private:
    char *codigo;
    double precio;
};

#endif /* PRODUCTOENTREGADO_H */

