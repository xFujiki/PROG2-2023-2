/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Cliente.h
 * Author: alulab14
 *
 * Created on 27 de octubre de 2023, 08:04 AM
 */

#ifndef CLIENTE_H
#define CLIENTE_H
#include <cstring>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstdlib>
#include "ProductoEntregado.h"
#include "Pedido.h"
using namespace std;
class Cliente {
public:
    Cliente();
    Cliente(const Cliente& orig);
    virtual ~Cliente();
    void SetMonto_total(double monto_total);
    double GetMonto_total() const;
    void SetCantidad_productos_entregados(int cantidad_productos_entregados);
    int GetCantidad_productos_entregados() const;
    void SetTelefono(int telefono);
    int GetTelefono() const;
    void SetNombre(const char* cad);
    void GetNombre(char *) const;
    void SetDni(int dni);
    int GetDni() const;
    void operator+=(Pedido &ped);
    void imprimePros(ofstream &rep);
private:
    int dni;
    char *nombre;
    int telefono;
    ProductoEntregado productos_entregados[100];
    int cantidad_productos_entregados;
    double monto_total;
};

bool operator>>(ifstream &arch,Cliente &cli);
ofstream &operator<<(ofstream &rep,Cliente &cli);
#endif /* CLIENTE_H */

