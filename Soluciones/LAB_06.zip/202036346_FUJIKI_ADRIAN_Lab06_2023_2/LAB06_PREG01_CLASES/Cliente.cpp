/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Cliente.cpp
 * Author: alulab14
 * 
 * Created on 27 de octubre de 2023, 08:04 AM
 */

#include "Cliente.h"
#include <cstring>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstdlib>
#include "Pedido.h"
using namespace std;
Cliente::Cliente() {
    cantidad_productos_entregados=0;
    dni=0;
    monto_total=0;
    nombre=nullptr;
    telefono=0;
}

Cliente::Cliente(const Cliente& orig) {
}

Cliente::~Cliente() {
    delete nombre;
}

void Cliente::SetMonto_total(double monto_total) {
    this->monto_total = monto_total;
}

double Cliente::GetMonto_total() const {
    return monto_total;
}

void Cliente::SetCantidad_productos_entregados(int cantidad_productos_entregados) {
    this->cantidad_productos_entregados = cantidad_productos_entregados;
}

int Cliente::GetCantidad_productos_entregados() const {
    return cantidad_productos_entregados;
}

void Cliente::SetTelefono(int telefono) {
    this->telefono = telefono;
}

int Cliente::GetTelefono() const {
    return telefono;
}

void Cliente::SetNombre(const char* cad) {
    if(nombre!=nullptr)delete nombre;
    nombre=new char[strlen(cad)+1];
    strcpy(nombre,cad);
}

void Cliente::GetNombre(char *cad) const {
    strcpy(cad,nombre);
}

void Cliente::SetDni(int dni) {
    this->dni = dni;
}

int Cliente::GetDni() const {
    return dni;
}

bool operator>>(ifstream &arch,Cliente &cli){
    int dni,telefono;
    char aux[100];
    
    arch>>dni;
    if(arch.eof())return false;
    arch.get();
    arch.getline(aux,100,',');
    arch>>telefono;
    cli.SetNombre(aux);
    cli.SetDni(dni);
    cli.SetTelefono(telefono);
    return true;    
}

void Cliente::operator+=(Pedido &ped){
    char aux[100];
    ped.GetCodigo(aux);
    productos_entregados[cantidad_productos_entregados].SetCodigo(aux);
    productos_entregados[cantidad_productos_entregados].SetPrecio(ped.GetPrecio_producto());
    cantidad_productos_entregados++;
    monto_total+=ped.GetPrecio_producto();
}

void Cliente::imprimePros(ofstream &rep){
    char aux[100];
    for(int i=0;i<cantidad_productos_entregados;i++){
        productos_entregados[i].GetCodigo(aux);
        rep<<left<<setw(10)<<aux;
    }
    rep<<right<<endl;
}

ofstream &operator<<(ofstream &rep,Cliente &cli){
    char aux[100];
    cli.GetNombre(aux);
    rep<<cli.GetDni()<<setw(5)<<" "<<left<<setw(45)<<aux<<right<<setw(12)<<
            cli.GetTelefono()<<setprecision(2)<<fixed<<
            setw(15)<<cli.GetMonto_total()<<" "<<
            "Productos entregados: ";
    if(cli.GetCantidad_productos_entregados()>0){
        cli.imprimePros(rep);
    }else{
        rep<<"NO SE LE ENTREGARON PRODUCTOS"<<endl;
    }
            
}