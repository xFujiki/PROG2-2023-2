/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Almacen.cpp
 * Author: alulab14
 * 
 * Created on 27 de octubre de 2023, 08:16 AM
 */

#include "Almacen.h"
#include "Cliente.h"
#include "Pedido.h"
#include <cstring>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstdlib>
using namespace std;
//Elaborado por Adrian Masashiri Fujiki Escobar 20203646
Almacen::Almacen() {
    cantidad_clientes=0;
    cantidad_productos=0;
}

Almacen::Almacen(const Almacen& orig) {
}

Almacen::~Almacen() {
}

void Almacen::SetCantidad_productos(int cantidad_productos) {
    this->cantidad_productos = cantidad_productos;
}

int Almacen::GetCantidad_productos() const {
    return cantidad_productos;
}

void Almacen::SetCantidad_clientes(int cantidad_clientes) {
    this->cantidad_clientes = cantidad_clientes;
}

int Almacen::GetCantidad_clientes() const {
    return cantidad_clientes;
}

void Almacen::cargar_cliente(){
    ifstream arch;
    arch.open("Clientes.csv",ios::in);
    if(!arch){
        cout<<"Error: No se ha podido abrir el archivo Clientes"<<endl;
        exit(1);
    }
    
    int i=0;
    while(1){
        if(arch>>arreglo_clientes[i]){
            i++;
        }else{
            break;
        }
    }
    cantidad_clientes=i;
}

void Almacen::cargar_producto(){
    ifstream arch;
    arch.open("Productos.csv",ios::in);
    if(!arch){
        cout<<"Error: No se ha podido abrir el archivo Productos"<<endl;
        exit(1);
    }
    
    int i=0;
    while(1){
        if(arch>>arreglo_productos[i]){
            i++;
        }else{
            break;
        }
    }
    cantidad_productos=i;
}

void Almacen::cargar_pedidos(){
    ifstream arch;
    arch.open("Pedidos.csv",ios::in);
    if(!arch){
        cout<<"Error: No se ha podido abrir el archivo Pedidos"<<endl;
        exit(1);
    }
    
    Pedido ped;
    
    char auxCod[100];
    int pos_pro,pos_cli;
    while(1){
        if((arch>>ped)==false)break;
        ped.GetCodigo(auxCod);
        pos_pro=buscarPro(auxCod);
        pos_cli=buscarCli(ped.GetDni_cliente());
        if(pos_pro!=-1){
            if(arreglo_productos[pos_pro]+=ped){//Si hay stock se agrega el pedido al cliente
                if(pos_cli!=-1){
                  arreglo_clientes[pos_cli]+=ped;
                }
            }
        }
    }
}

int Almacen::buscarPro(char *auxCod){
    char codPro[100];
    for(int i=0;i<cantidad_productos;i++){
        arreglo_productos[i].GetCodigo(codPro);
        if(strcmp(codPro,auxCod)==0)return i;
    }
    return -1;
}

int Almacen::buscarCli(int auxDni){
    for(int i=0;i<cantidad_clientes;i++){
        if(arreglo_clientes[i].GetDni()==auxDni)return i;
    }
    return -1;
}

void imprimeLinea(ofstream &rep,int cant,char car){
    rep<<endl;
    for(int i=0;i<cant;i++){
        rep<<car;
    }
    rep<<endl;
}

void Almacen::mostrar_datos(){
    ofstream rep;
    rep.open("ReporteDeAlmacen.txt",ios::out);
    if(!rep){
        cout<<"ERROR: No se ha podido abrir el archivo de reporte"<<endl;
        exit(1);
    }
    rep<<setw(77)<<"Almacen De Productos S.A."<<endl<<setw(74)<<
            "Relacion de clientes";
    
    imprimeLinea(rep,185,'=');
    rep<<"DNI"<<setw(16)<<"Nombre"<<setw(50)<<"Telefono"<<setw(20)<<"Monto total";
    imprimeLinea(rep,185,'-');
    for(int i=0;i<cantidad_clientes;i++){
        rep<<arreglo_clientes[i];
        rep<<endl;
    }
    
    rep<<setw(40)<<"Relacion de productos";
    imprimeLinea(rep,185,'=');
    rep<<"Codigo"<<setw(20)<<"Descripcion"<<setw(61)<<"Precio"<<setw(10)<<"Stock";
    imprimeLinea(rep,185,'-');
    for(int i=0;i<cantidad_productos;i++){
        rep<<arreglo_productos[i];
        imprimeLinea(rep,185,'-');
    }
}