/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: alulab14
 *
 * Created on 27 de octubre de 2023, 09:08 AM
 */

#include <cstdlib>
#include <cstring>
#include <iomanip>
#include <iostream>
#include <fstream>
#include "Almacen.h"
using namespace std;

//Elaborado por Adrian Masashiri Fujiki Escobar 20203646
int main(int argc, char** argv) {
    Almacen almacen;
    
    almacen.cargar_cliente();
    almacen.cargar_producto();
    almacen.cargar_pedidos();
    almacen.mostrar_datos();
    return 0;
}

