/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: alulab14
 *
 * Created on 22 de septiembre de 2023, 07:59 AM
 */

#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <fstream>

#include "PunterosGenericos.h"
#include "MuestraPunteros.h"
using namespace std;
//Adrian Fujiki Escobar 20203646

int main(int argc, char** argv) {
    void *productos,*clientes;
    
    cargaproductos(productos);
    //prueba
    imprimeproductos(productos);
    //-
    cargaclientes(clientes);
    //prueba
    imprimeclientes(clientes);
    //-
    cargapedidos(productos,clientes);
    //prueba
    imprimerepfinal(clientes);
    //-
    imprimereporte(clientes);
    return 0;
}

