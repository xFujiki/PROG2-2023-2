/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   PunterosGenericos.h
 * Author: alulab14
 *
 * Created on 22 de septiembre de 2023, 08:02 AM
 */

#ifndef PUNTEROSGENERICOS_H
#define PUNTEROSGENERICOS_H
#include <fstream>
//Adrian Fujiki Escobar 20203646
using namespace std;

void AperturaDeArchivoParaLeer(ifstream &arch,const char*cad);
void AperturaDeArchivoParaEscribir(ofstream &arch,const char*cad);
void cargaproductos(void *&productos);
void *leerProducto(ifstream &arch);
char *leerCadena(ifstream &arch);

void cargaclientes(void *&clientes);
void *leerCliente(ifstream &arch);

void cargapedidos(void *&productos,void *&clientes);
void agregar_pedido(void *&clientes,int pos_cli,char *cod,int cant,double cobro,
        int nPed);
int alcanza_linea(double cobro,void *&clientes,int dni);
int hay_linea(void *productos,char *cod,double &precio);
int buscarCli(void *clientes,int dni);

void imprimeLinea(ofstream &rep,int cant,char car);
void imprimereporte(void *clientes);
#endif /* PUNTEROSGENERICOS_H */
