/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   PunterosGenericos.cpp
 * Author: alulab14
 * 
 * Created on 22 de septiembre de 2023, 08:02 AM
 */

#include "PunterosGenericos.h"
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstring>
#define MAX_LIN 120

using namespace std;
//Adrian Fujiki Escobar 20203646

void AperturaDeArchivoParaLeer(ifstream &arch,const char*cad){
    arch.open(cad,ios::in);
    if(!arch){
        cout<<"No se puede abrir el archivo "<<cad<<endl;
        exit(1);
    }
}
void AperturaDeArchivoParaEscribir(ofstream &arch,const char*cad){
    arch.open(cad,ios::out);
    if(!arch){
        cout<<"No se puede abrir el archivo "<<cad<<endl;
        exit(1);
    }
}

void cargaproductos(void *&productos){
    ifstream arch;
    AperturaDeArchivoParaLeer(arch,"Productos2.csv");
    
    void *pro[700]{};
    int nPro=0;
    while(1){
        pro[nPro]=leerProducto(arch);
        if(pro[nPro]==nullptr)break;
        nPro++;
    }
    
    void **v_pro;
    v_pro=new void*[nPro+1]{};
    
    for(int i=0;i<=nPro;i++){
        v_pro[i]=pro[i];
    }
    
    productos=v_pro;
}


void *leerProducto(ifstream &arch){
    char *cod;
    char *desc,c;
    double *precio=new double;
    char *tipo=new char;
    
    cod=leerCadena(arch);
    if(cod==nullptr)return nullptr;
    desc=leerCadena(arch);
    arch>>*precio>>c>>*tipo>>ws;
    //anadhi el ws
    void **v_pro;
    v_pro=new void*[4];
    
    v_pro[0]=cod;
    v_pro[1]=desc;
    v_pro[2]=precio;
    v_pro[3]=tipo;
    
    return v_pro;
}

void cargaclientes(void *&clientes){
    ifstream arch;
    AperturaDeArchivoParaLeer(arch,"Clientes2.csv");
    
    void *cli[700]{};
    int nCli=0;
    while(1){
        cli[nCli]=leerCliente(arch);
        if(cli[nCli]==nullptr)break;
        nCli++;
    }
    
    void **v_cli;
    v_cli=new void*[nCli+1]{};
    
    for(int i=0;i<=nCli;i++){
        v_cli[i]=cli[i];
    }
    
    clientes=v_cli;
}

//79464412,PORTUGAL RAFFO ALEXANDER,3902394,10000
void *leerCliente(ifstream &arch){
    int *dni=new int;
    char *nom,c;
    double *lin=new double;
    int telefono;
    
    arch>>*dni;
    if(arch.eof())return nullptr;
    arch>>c;
    nom=leerCadena(arch);
    arch>>telefono>>c>>*lin;
    
    void **v_cli;
    v_cli=new void*[4];
    v_cli[0]=dni;
    v_cli[1]=nom;
    v_cli[2]=nullptr;
    v_cli[3]=lin;
    
    return v_cli;
}

char *leerCadena(ifstream &arch){
    char *cad,aux[100];
    arch.getline(aux,100,',');
    if(arch.eof())return nullptr;
    cad=new char[strlen(aux)+1];
    strcpy(cad,aux);
    return cad;
}

//codigo,dni,cant
//JXD-139,50375303,6

//a producto no se le hace nada
void cargapedidos(void *&productos,void *&clientes){
    ifstream arch;
    AperturaDeArchivoParaLeer(arch,"Pedidos2.csv");
    //si el producto no necesita linea de credito se asigna 'N'
    //si requiere linea de credito descuenta el credito del cliente 'S'
    
    char *cod,c;
    int dni;
    int cant;
    int pos_cli;
    int nPed[700]{};
    double precio,cobro;
    
    //reutilizado
    void **cli=(void **)clientes;
    void **reg;
    void **det;
    
    void **auxcli;
    while(1){
        cod=leerCadena(arch);
        if(cod==nullptr)break;
        arch>>dni>>c>>cant>>ws;
        
        pos_cli=buscarCli(clientes,dni);
        
        if(pos_cli!=-1){//si el cliente existe
            if(hay_linea(productos,cod,precio)){//si requiere linea se actualiza el cliente
                //esta funcion tambien retorna el precio del producto
                cobro=precio*cant;
                if(alcanza_linea(cobro,clientes,dni)){
                    //si alcanza linea se agrega el pedido, asimismo actualiza la linea
                    if(nPed[pos_cli]==0){
                        reg=(void **)cli[pos_cli];
                        auxcli=new void*[700]{};
                        reg[2]=auxcli;
                    }
                    agregar_pedido(clientes,pos_cli,cod,cant,cobro,nPed[pos_cli]);
                    nPed[pos_cli]++;
                }
            }else{//si no hay linea solo se asigna
                if(nPed[pos_cli]==0){
                        reg=(void **)cli[pos_cli];
                        auxcli=new void*[700]{};
                        reg[2]=auxcli;
                }
                cobro=precio*cant;
                agregar_pedido(clientes,pos_cli,cod,cant,cobro,nPed[pos_cli]);
                nPed[pos_cli]++;
            }
        }
    }
    
    //recorta
    void **aux;
    for(int i=0;cli[i]!=nullptr;i++){
        if(nPed[i]>0){
            reg=(void **)cli[i];
            aux=new void *[nPed[i]+1]{};
            det=(void **)reg[2];
            for(int k=0;k<=nPed[i];k++){
                aux[k]=det[k];
            }
            reg[2]=aux;
        }
    }
}

//agregando pedido
void agregar_pedido(void *&clientes,int pos_cli,char *cod,int cant,double cobro,
        int nPed){
    void **v_cli=(void **)clientes;
    void **reg;
    reg=(void **)v_cli[pos_cli];
    
    void **det;
    det=(void **)reg[2];//colita
    
    void **ped;
    ped=new void*[3];
    
    int *cantidad=new int;
    double *total=new double;
    
    *cantidad=cant;
    *total=cobro;
    
    ped[0]=cod;
    ped[1]=cantidad;
    ped[2]=total;
    
    det[nPed]=ped;
}

//esta funcion actualiza la linea (revisar)
//ampersan?
int alcanza_linea(double cobro,void *&clientes,int dni){
    void **v_cli=(void **)clientes;
    
    //double *aux_cobro=new double;
    void **reg;
    for(int i=0;v_cli[i]!=nullptr;i++){
        reg=(void **)v_cli[i];
        if(dni==*(int *)reg[0]){//se encuentra
            if(*(double*)reg[3]>0&&cobro<=*(double*)reg[3]){//si alcanza
                *(double *)reg[3]-=cobro;
                //*aux_cobro=*(double*)reg[3]-cobro;
                //reg[3]=aux_cobro;
                return 1;
            }else{
                return 0;
            }
        }
    }
}

//revisar esto
int hay_linea(void *productos,char *cod,double &precio){
    void **v_pro=(void **)productos;
    
    void **reg;
    for(int i=0;v_pro[i]!=nullptr;i++){
        reg=(void **)v_pro[i];
        //revisar esta linea
        if(strcmp((char*)reg[0],cod)==0){//si encuentra el producto
           if(*(char*)reg[3]=='S'){//si es S
                precio=*(double *)reg[2];
                return 1;
            }else{
                return 0;
            } 
        } 
    }
}

int buscarCli(void *clientes,int dni){
    void **v_cli=(void **)clientes;
    
    void **reg;
    for(int i=0;v_cli[i]!=nullptr;i++){
        reg=(void **)v_cli[i];
        if(dni==*(int *)reg[0]){
            return i;
        }
    }
    return -1;
}

void imprimeLinea(ofstream &rep,int cant,char car){
    rep<<endl;
    for(int i=0;i<cant;i++){
        rep<<car;
    }
    rep<<endl;
}

void imprimereporte(void *clientes){
    ofstream rep;
    AperturaDeArchivoParaEscribir(rep,"ReporteFinal.txt");
    
    void **v_cli;
    v_cli=(void **)clientes;

    void **reg;
    
    void **det;
    
    void **ped;
    for(int i=0;v_cli[i]!=nullptr;i++){
        reg=(void **)v_cli[i];
        imprimeLinea(rep,MAX_LIN,'=');
        rep<<"DNI"<<setw(21)<<"NOMBRE"<<setw(54)<<"CREDITO"<<endl;
        rep<<*(int *)reg[0]<<setw(10)<<" "<<left<<setw(50)<<(char *)reg[1]
                <<setprecision(2)<<fixed<<right<<setw(10)<<*(double*)reg[3];
        imprimeLinea(rep,MAX_LIN,'-');
        rep<<"Pedidos atendidos: ";
        imprimeLinea(rep,MAX_LIN,'-');
        rep<<"Codigo"<<setw(13)<<"Cantidad"<<setw(10)<<"Total";
        imprimeLinea(rep,MAX_LIN,'-');
        
        det=(void **)reg[2];
        
        if(det!=nullptr){
            for(int k=0;det[k]!=nullptr;k++){
                ped=(void **)det[k];
                rep<<(char *)ped[0]<<setw(5)<<*(int *)ped[1]<<setw(19)<<
                        *(double*)ped[2]<<endl;
            }
        }
    }
}